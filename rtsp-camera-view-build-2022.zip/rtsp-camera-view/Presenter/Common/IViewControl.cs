﻿namespace Presenter.Common
{
    public interface IViewControl
    {
    }
}