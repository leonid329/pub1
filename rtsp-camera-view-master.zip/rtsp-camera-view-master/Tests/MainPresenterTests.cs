﻿using System;
using Model;
using Presenter.Common;
using Presenter.Presenters;
using Presenter.Views;
using NSubstitute;
using NUnit.Framework;

namespace Tests
{
    [TestFixture]
    public class MainPresenterTests
    {
    }
}